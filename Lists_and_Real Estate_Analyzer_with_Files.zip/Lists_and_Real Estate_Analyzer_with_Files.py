###Lists and Real Estate Analyzer version with files
###Author: Harold Stevens
###11/7/2024

import csv
from statistics import mean, median

def getDataInput(filename):
    with open(filename, 'r') as file:
        reader = csv.DictReader(file)
        return list(reader)

def main():
    data = getDataInput("RealEstateData.csv")
    prices = []
    city_totals = {}
    zip_totals = {}
    property_type_totals = {}

    for record in data:
        try:
            city = record['city']
            zip_code = record['zip']
            property_type = record['type']
            price = float(record['price'])

            prices.append(price)
            
            city_totals[city] = city_totals.get(city, 0) + price
            zip_totals[zip_code] = zip_totals.get(zip_code, 0) + price
            property_type_totals[property_type] = property_type_totals.get(property_type, 0) + price
        except (ValueError, KeyError) as e:
            print(f"Error processing record: {record}. Error: {e}")

    if not prices:
        print("No valid prices were found in the data.")
        return

    print(f"Minimum property price: ${min(prices):,.2f}")
    print(f"Maximum property price: ${max(prices):,.2f}")
    print(f"Total value of all properties: ${sum(prices):,.2f}")
    print(f"Average property price: ${mean(prices):,.2f}")
    print(f"Median property price: ${median(prices):,.2f}")

    print("\nSummary by Property Type:")
    for prop_type, total in property_type_totals.items():
        print(f"{prop_type}: ${total:,.2f}")

    print("\nSummary by City:")
    for city, total in city_totals.items():
        print(f"{city}: ${total:,.2f}")

    print("\nSummary by Zip Code:")
    for zip_code, total in zip_totals.items():
        print(f"{zip_code}: ${total:,.2f}")

if __name__ == "__main__":
    main()
