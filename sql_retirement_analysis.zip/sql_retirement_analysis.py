import sqlite3
import csv

# Part 1: Data creation, import and insertion

# Create SQLite database and connect to it
conn = sqlite3.connect('employee_database.db')
cursor = conn.cursor()

# Create tables
cursor.execute('''CREATE TABLE IF NOT EXISTS Employee
                  (EmployeeID INTEGER PRIMARY KEY, Name TEXT)''')

cursor.execute('''CREATE TABLE IF NOT EXISTS Pay
                  (EmployeeID INTEGER PRIMARY KEY, Year INTEGER, Earnings REAL)''')

cursor.execute('''CREATE TABLE IF NOT EXISTS SocialSecurityMin
                  (Year INTEGER PRIMARY KEY, Minimum REAL)''')

# Import data from text files
def import_data(file_name, table_name, columns):
    with open(file_name, 'r') as file:
        csv_reader = csv.reader(file)
        next(csv_reader)  # Skip header row
        for row in csv_reader:
            placeholders = ','.join(['?' for _ in row])
            try:
                cursor.execute(f"INSERT OR REPLACE INTO {table_name} ({columns}) VALUES ({placeholders})", row)
            except sqlite3.IntegrityError:
                print(f"Skipping duplicate entry: {row}")

import_data('Employee.txt', 'Employee', 'EmployeeID, Name')
import_data('Pay.txt', 'Pay', 'EmployeeID, Year, Earnings')
import_data('SocialSecurityMinimum.txt', 'SocialSecurityMin', 'Year, Minimum')

# Commit the changes
conn.commit()

# Part 2: Data Reporting

# Join tables and process data
cursor.execute('''
    SELECT e.Name, p.Year, p.Earnings, s.Minimum
    FROM Employee e
    JOIN Pay p ON e.EmployeeID = p.EmployeeID
    JOIN SocialSecurityMin s ON p.Year = s.Year
    ORDER BY e.Name, p.Year
''')

# Process and print results with formatting
print(f"{'Name':<20} {'Year':<6} {'Earnings':>12} {'Minimum':>12} {'Eligible':<5}")
print('-' * 55)  # Print a separator line

for row in cursor.fetchall():
    name, year, earnings, minimum = row
    status = "Yes" if earnings >= minimum else "No"
    print(f"{name:<20} {year:<6} {earnings:>12,.2f} {minimum:>12,.2f} {status:<5}")

# Close the connection
conn.close()

