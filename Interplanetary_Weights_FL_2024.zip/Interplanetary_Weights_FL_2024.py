#Date: 11/3/2024
#Author: Harold Stevens
#Interplanetary Weights

import pickle

#function to validate input
def Validate_Input( sPrompt ):
    fNumber = 0
    while fNumber <= 0 :
        try:
            fNumber = float( input( sPrompt ))
        except ValueError:
            print( "Input must be a numeric value" )
    return fNumber

def Main():

    #dictionary declaration
    dictPlanetWeightFactors = {
        "Mercury"   :0.38,
        "Venus"     :0.91,
        "Moon"      :0.165,
        "Mars"      :0.38,
        "Jupiter"   :2.34,
        "Saturn"    :0.93,
        "Uranus"    :0.92,
        "Neptune"   :1.12,
        "Pluto"     :0.066
    }

    #dictionary declaration, assigning data from a file if one exists, prompting user to view the previous data
    dictPlanetHistory = {}
    #try to open a file object, if one exists, to store to a multi-dimensional dictionary
    try:
        oFileObject = open( "PlanetaryWeights.db", "rb" )
        dictPlanetHistory = pickle.load( oFileObject )
        if input( "Would you like to see the history?: " ).lower() == "y":
            #dictionary for loop with name as key and a nested dictionary as value
            for name, dictWeights in dictPlanetHistory.items():
                print( f"{name}, here are your weights on Solar System's planets" )
                #secondary loop to iterate through the nested dictionary with the planet at the key and weight being the value
                for planet, weight in dictWeights.items():
                    print( f"Weight on {planet:10s} {weight:10,.2f}" )
        oFileObject.close()
    except:
        print("No file found")

    #main loop to continue iterating until no name is entered
    while True:
        sName = input( "Enter Name: " ).title()
        if sName == "":
            break
        if sName in dictPlanetHistory:
            continue
        fWeight = Validate_Input( "Enter Weight: " )
        dictPersonWeights = {}
        print( f"{sName}, here are your weights on our Solar System's Planets" )
        for planet, factor in dictPlanetWeightFactors.items():
            fCalculatedWeight = fWeight * factor
            dictPersonWeights[planet] = fCalculatedWeight
            print( f"{planet:10s} {fCalculatedWeight:10,.2f}" )
        dictPlanetHistory[sName] = dictPersonWeights

        #opens a .db file and dumps teh dictPlanetHistory dictionary data into it to be used later on a separate run
        with open( "PlanetaryWeights.db", "wb" ) as file:
            pickle.dump( dictPlanetHistory, file )

Main()
